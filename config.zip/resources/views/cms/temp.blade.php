@extends('cms.parent')

@section('title', '')

@section('styles')

@endsection

@section('sub-title', '')

@section('main-content')

@endsection

@section('scripts')

@endsection
