<?php

namespace App\Http\Controllers\cms\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use Illuminate\Foundation\Auth\SendsPasswordResetEmails;


class ForgetPasswordController extends Controller
{
//    use SendsPasswordResetEmails;
}
